const DOMAIN = "192.168.0.108"
const BASE_URL = `http://${DOMAIN}:5000/api`

export default BASE_URL